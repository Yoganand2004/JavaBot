import java.io.*;

/**
 *Write a program to input a number.
 *Display the position of given number in the list
 *if number is not found in the list then print "search element not found"
 *use binary search
 */
public class BinarySearch
{

     public void display ()throws IOException
    {
        int arr[]={1,3,4,6,7,10,12,23,33,45,55,56,57,58,60};
        
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
                System.out.println("Enter number to be search");
              int n=Integer.parseInt(br.readLine());
              int low=0,high=arr.length-1,mid=0,flag=-1;
              while(low<=high)
              { 
                  mid=(low+high)/2;
                  if(n==arr[mid])
                  {
                      flag=1;
                      break;
                    }
                    if(n>arr[mid])
                    {
                        low=mid+1;
                    }
                    else if(n<arr[mid])
                    {
                        high=mid-1;
                    }
                }
                if(flag==1)
                {
                         System.out.println(n+"Found at position "+(mid+1));
                        }
                        else 
                        {
                         System.out.println(" search element not found");
                         
                        }
                     }//end method
}	//end class
   
                        