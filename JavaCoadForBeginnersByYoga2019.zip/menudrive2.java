/**  Using a switch case statement write a Menu Driven program
 * 
  NO 1:triangle patter
  NO 2:inveted triangle
 * 
 */ 
import java.io.*;
public class menudrive2
{
    public void display ()throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Menudriven");
        System.out.println("1.triangle patter");
        System.out.println("2.inveted triangle");
        System.out.println("ENTER CHOICE");
          int n=Integer.parseInt(br.readLine());
          
          
          switch(n)
          {
          case 1:
          System.out.println("enter range of number");
          int n1=Integer.parseInt(br.readLine());
         
          for(int i=1;i<=n1;i++)
          {
              
              for(int j=1;j<=i;j++)
              {
                  System.out.print(j+" ");
                }
              System.out.println();
            }
            break;
            case 2:
           System.out.println("enter range of number");
           int n2=Integer.parseInt(br.readLine());
           
           for(int x=n2;x>=1;x--)
           {
                
               for(int j=1;j<=x;j++)
               {
               System.out.print(j+" ");
            }
               System.out.println();
            }
            break;
            default :
            System.out.print("invalid input ");
        }
    }//method ends
}//class ends
               