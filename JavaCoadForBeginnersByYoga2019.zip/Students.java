/** Write a program to input name and total marks of students
 * and prints average and Deviation of student. 
 * 
 */
import java .util.*;
public class Students
{
    int n,i,s=0;
    double avg,d;
     public void display()
    { 
        Scanner sc=new Scanner(System.in);
         System.out.println("Enter number of students"); 
         n=sc.nextInt();
        String [] name =new String[n];
        int totalmarks[] =new int[n];
          for( i=0;i<n;i++)
          {
              System.out.println("Enter name and total marks"); 
              name[i]=sc.nextLine();
              totalmarks[i]=sc.nextInt();
              s=s+totalmarks[i];
            }
            avg=(double)s/n;
            System.out.println("Average="+avg);
            for( i=0;i<n;i++)
            {
                d=totalmarks[i]-avg;
                  System.out.println(name[i]+"Deviation is"+d);
                }
            }//end method
}	//end class
   
                        
            
        
        
       
      
        
     
      
        