/*To print Tech number
between 1000 to 9999
*/
import java.io.*;
public class tech_number
{
    public boolean tech_no_check(int n)
    {
        int a=n/100;
        int b=n%100;
        int c=(int)Math.pow((a+b),2); 
        return c==n?true:false;
      
    }

     public void main()
     {
         for(int a=1000;a<=9999;a++)
         {
             if(tech_no_check(a))
             {
                 System.out.println(a);
                }
                
            }
       }//end method
}	//end class
        
        