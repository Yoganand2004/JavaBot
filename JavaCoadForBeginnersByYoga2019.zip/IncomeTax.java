import java.io.*;
/**Income tax for male citizen below age 65
 * Write a program to input age,gender and taxable income of a person
 * but age should be less than 65 years
 * 
 */
public class IncomeTax
{
   

    
    public void input()throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter age");
        int age=Integer.parseInt(br.readLine());
          System.out.println("Enter gender");
          String gender=br.readLine();
        System.out.println("Enter taxable income ");
        int income=Integer.parseInt(br.readLine());
        
        if(age>65||gender.equalsIgnoreCase("Female"))
        { 
            System.out.println("Wronge categor ");
        }
        else
        {
            double tax=0.0;
             if(income<=160000)
             {
             tax=0.0;
            }
            else if(income>160000&&income<=500000)
          {
              tax=(income-16000)*10/100;
            }
            else if(income>500000&&income<800000)
            {
            tax=(income-500000)*(20/100)+34000;
        }
            else
            {
            tax=(income-800000)*(30/100)+94000;
        }
             System.out.println("Your Income Tax is  "+tax);
        }
     }//end method
}	//end class
   
                             