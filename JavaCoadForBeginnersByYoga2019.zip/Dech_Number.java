/**To print Dech number
between 1000 to 9999
*/


public class Dech_Number
{
    public boolean isdech(int n)
    {
        int d=n%100;
        int m=n/100;
        int ar=(d*m)+(d*m);
    
    if(ar==n)
    return true;
    else 
    
    return false;
}
public void Main()
{
    for(int x=1000;x<=9999;x++)
    {
        if(isdech(x))
        System.out.println(x);
    }
    }//end method
}	//end class
        
    