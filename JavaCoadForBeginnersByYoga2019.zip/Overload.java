/**
 * Write a program to Overload a function 
 *Accept a number and print sum of its factorial
 *accept number and range and prints sum of series.
 */
public class Overload
{
    public double series(double n)
    {
        double s=0.0;
        for(int x=1;x<=n;x++)
        {
            int f=1;
            
        for(int y=1;y<=x;y++)
        {
            f=f*y;
        }
        double fr=(double)1.0/f;
        s=s+fr;
    }
    return s;
   }//end method
     public double series(double a,double n)
     {
         double s=0.0;
         int p=2;
          for(int x=1;x<=n*2;x=x+2)
          {
            double ar=(double)x/(Math.pow(a,p));
            s=s+ar;
            p=p+4;
        }
        return s;
  }//end method
}	//end class
   
                               