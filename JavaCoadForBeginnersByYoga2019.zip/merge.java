/**Write a program to store 6 element in an array P and 4 element in array Q . Now produce  a third array R ,containing all the element
 * of array P and Q .Display the resulant array
 */ 
import java.io.*;
public class merge
{
    public static void main(String[] args)throws IOException
    {
        int i,j,c=0;
        int p[]=new int[6];
        int q[]=new int[4];
        int r[]=new int[10];
         BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
         for(i=0;i<6;i++)
         {
                 System.out.println("enter the element of 1st array");
                 p[i]=Integer.parseInt(br.readLine());
                }
                for(j=0;j<4;j++)
         {
                 System.out.println("enter the element of 2nd array");
                 q[j]=Integer.parseInt(br.readLine());
                }
                for( i=0;i<10;i++)
         {
             if(i<6)
             {
                 r[i]=p[i];
                }
                 else
                 {
                     r[i]=q[c];
                     c++;
                    }
                }
                 System.out.println("enter the element of 3rd array");
               for( i=0;i<10;i++)
               {
                   System.out.println(r[i]);
                }
                 }//end method
}	//end class
   
                        
                 