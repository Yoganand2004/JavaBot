/**To print special  number
special  number is a number which is equal to sum of the factorial 
of its each digit.
Write a program to check weather the number is special  number or not.
*/


import java.io.*;
public class special_number_checking
{
    public int factorial(int n)
    {
        int f=1;
        for(int x=1;x<=n;x++)
        {
            f=f*x;
        }
        return f;//returning factorial  
    }
    public void ckeck()throws IOException
    {
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
{
    System.out.println("Enter the Number");
    int n=Integer.parseInt(br.readLine());
    int s=0;
    int temp=n;
    while(n>0)
    {
        int a=n%10;
        int b=factorial(a);
        s=s+b;
        n=n/10;
    }
if(temp==s)
{
    System.out.println(temp +" is special number");
}
else
{
    System.out.println(temp +" is not special number");    
}
}

    }//end method
}	//end class
        