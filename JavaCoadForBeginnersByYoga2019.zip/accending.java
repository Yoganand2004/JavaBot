import java.io.*;
public class accending
{
    public void display()throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter line of text");
        String str=br.readLine();
        str=str+" ";
        String arr[]=new String[str.length()];
        String wd="";int c=0;
        for(int x=0;x<str.length();x++)
        {
            char ch=str.charAt(x);
            if(ch!=' ')
            {
            wd=wd+ch;
             }
            else
            {
                arr[c]=wd;
                wd="";
                c++;
            }
        }
        int i=0;
        for(int x=0;x<c;x++)
        {
            int l=arr[x].length();
            if(i<=l)
            {
                i=l;
            }
        }
            for(int x=0;x<=i;x++)
            {
                for(int y=0;y<c;y++)
                {
                    int l=arr[y].length();
                    if(x==l)
                    System.out.print(arr[y]+" ");
                }
            }
        }
    }
 
            
        
            
            
            


    
    