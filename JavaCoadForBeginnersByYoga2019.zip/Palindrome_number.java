/**To print Palindrome number
between 100 to 1000
*/
public class Palindrome_number
{
    public void number(int n)
    {
        
        System.out.println("checking pelindrome");
        int rev=0;
        int rem;
        int temp=n;
        while(n>0)
        {
            rem=n%10;
            rev=rev*10+rem;
            n=n/10;
        }
        if(temp==rev)
        
            System.out.println(temp+" is a palindrome number");
            else
            System.out.println(temp+" is not a palindromr number");
        
 }//end method
}	//end class
        
    
