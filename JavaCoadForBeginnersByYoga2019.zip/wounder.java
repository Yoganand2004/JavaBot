import java.io.*;
/**Write a program to input country name and check whether is wonder country or not.
 * 
 */
public class wounder
{

    
    public void ckeck()throws IOException
    {
String won[]={"CHICHEN ITZA ","CHRIST THE REDEEMER","TAJ MAHAL","GREAT WALL OF CHINA","MACHU PICCHU","PETRA","COLOSSEUM"};
        String loc[]={"MEXICO","BRAZIL","INDIA","CHINA","PERU","JORDAN","ITLAY"};
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

{
    
    System.out.println("Enter Country name");
        String s=br.readLine();
    int f=0;
    for(int i=0;i<7;i++)
    {
        if(s.equalsIgnoreCase(loc[i]))
        {  System.out.println(loc[i]+"-"+won[i]);  f=1;
            break;
        }
    }
        if(f==0)
        {
              System.out.println("SORRY NOT FOUND");
            }
        }
    }//end method
}	//end class
   
                        
            
        
        
        
        
        
        