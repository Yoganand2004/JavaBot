/**  Using a switch case statement write a Menu Driven program
 * 
  NO 1:ALPHABATE AND ITS ASSIC VALUE
  NO 2:# AND * pattern
 * 
 */ 
import java.io.*;
public class menudrive3
{
    public void display ()throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Menudriven");
        System.out.println("1.ALPHABATE AND ITS ASSIC VALUE");
        System.out.println("2.# AND * pattern");
        System.out.println("ENTER CHOICE");
          int n=Integer.parseInt(br.readLine());
          
          
          switch(n)
          {
          case 1:
           System.out.println("alphabate"+"\t"+"ascii value");
          
          for(int i=65;i<=90;i++)
          {
              char ch=(char)i;
              
              System.out.println(ch+"                   "+i);
            }
            break;
            case 2:
           System.out.print("enter range ");
           int n1=Integer.parseInt(br.readLine());
           
           for(int x=1;x<n1;x++)
           {
                int a=1;
               for(int j=1;j<=x;j++)
               {
                   a++;
                   if(a%2==0)
                    System.out.print("# ");
                   else
                    System.out.print("* ");
             
              
            }
               System.out.println();
            }
            break;
            default :
            System.out.print("invalid input ");
        }
 }//end method
}	//end class
              