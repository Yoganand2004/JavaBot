/**To print Spy number
between 1 to 1000
*/


public class SpyNumber
{
    public boolean isspy(int n)
    {
        int s=0,p=1;
        while(n>1)
        {
            int a=n%10;
            s=s+a;
            p=p*a;
            n=n/10;
        }
        if(s==p)
        return true;
        else
        return false;
    }
public void generate()
{
    for(int i=1;i<=1000;i++)
    {
        if(isspy(i))
        System.out.println(i);
    }
}//end method
}	//end class
        
        
            