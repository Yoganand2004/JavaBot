/**  Using a switch case statement write a Menu Driven program
 * 
  NO 1:floyds trianle
  NO 2:ICSE pattern
 * 
 */ 
import java.io.*;
public class menudrive1
{
    public void display ()throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Menudriven");
        System.out.println("1.floyds trianle");
        System.out.println("2.ICSE pattern");
        System.out.println("ENTER CHOICE");
          int n=Integer.parseInt(br.readLine());
          
          
          switch(n)
          {
          case 1:
          System.out.println("enter range of number");
          int n1=Integer.parseInt(br.readLine());
          int c=0;
          for(int i=1;i<=n1;i++)
          {
              int s=0;
              for(int j=1;j<=i;j++)
              {
                  c++;
                  s=s+c;
                  System.out.print(c+" ");
                }
                  System.out.print(s);
              System.out.println();
            }
            break;
            case 2:
           System.out.print("input string ");
           String str=br.readLine();
           int l=str.length();
           for(int x=0;x<l;x++)
           {
                
               for(int j=0;j<=x;j++)
               {
              char ch=str.charAt(j);
               System.out.print(ch+" ");
            }
               System.out.println();
            }
            break;
            default :
            System.out.print("invalid input ");
        }
     }//end method
}	//end class
               