
/**  Using a switch case statement write a Menu Driven program
 * 
  NO 1:print 20 prime
  NO 2:automorphic number
 * 
 */
import java.io.*;
public class menudrive4
{
    public void display ()throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Menudriven");
        System.out.println("1.print 20 prime");
        System.out.println("2.automorphic number");
        System.out.println("ENTER CHOICE");
          int n1=Integer.parseInt(br.readLine());
          
          
          switch(n1)
          {
          case 1:
            int n2=2;
        
        for(int i=1;i<=20; )
        {
         int b=primeCheck(n2);
         if(b==2)
         {
             System.out.println(n2);
             i++;
            }
            n2++;
            }
            break;
            case 2:
             System.out.println("ENTER A NUMBER");
              int n=Integer.parseInt(br.readLine());
              int p=n*n;
              int m,q,r,c=0;
              m=n;
              while(n>0)
              {
                  q=n/10;
                  c=c+1;
                  n=q;
                }
                r=(int)(p%(Math.pow(10,c))); 
                if(m==r)
                 System.out.println("it is automorphic number");
             else
             System.out.println("it is not automorphic number");
                 break;
           default:
           System.out.println("invalid input");
          
          
          
        }
    }
public int primeCheck(int n)
    {
        int c=0;
        for(int i=1;i<+n;i++)
        {
            if(n%i==0)
            c++;
        }
        if(c==2)
        {
            return c;
        }
        else
        {
            return 0;
        }
}//end method
}	//end class
   
               