/**
 * Write a program to input name and price of item purchased
 * and print cost after discount.
 */
import java.io.*;
public class ShowRoom
{
    String name,mob;
    double cost,dis,amt;
    

    public ShowRoom()
    {
        name="";
        mob="";
        cost=0.0;
        dis=0.0;
        amt=0.0;
    }
    public void input()throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter your name");
        name=br.readLine();
        System.out.println("Enter your mobile number");
        mob=br.readLine();
        System.out.println("Enter the cost");
        cost=Double.parseDouble(br.readLine());
    }//end method
    public void calculate()
    {
        if(cost<=10000)
            dis=0.05;
            else if(cost>10000&&cost<=20000)
            dis=0.1;
            else if(cost>20000&&cost<=35000)
            dis=0.15;
            else if(cost>35000)
            dis=0.2;
        amt=cost-(dis*cost);
    }//end method
    public void display()
    {
      
        
                System.out.println("Name"+"        "+"moblie no"+"        +"+"Amount");
                 System.out.println(name+"   "+mob+"           "+amt);
                }//end method
     

                  
            public  void main()throws IOException
    {
       ShowRoom ob=new ShowRoom();
        ob.input();
        ob.calculate();
        ob.display();
    }//end method
}	//end class
   
                        
        

    