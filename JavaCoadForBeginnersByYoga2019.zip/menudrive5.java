/**  Using a switch case statement write a Menu Driven program
 * 
  NO 1:Fibonacci Series
  NO 2:Sum of digit of number
 * 
 */
import java.io.*;

public class menudrive5
{
     public void display ()throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Menudriven");
        System.out.println("1.Fibonacci Series");
        System.out.println("2.Sum of digit of number");
        System.out.println("ENTER CHOICE");
          int n1=Integer.parseInt(br.readLine());
          
          
          switch(n1)
          {
          case 1:
          int f=0,s=1,t;
          System.out.print(f+" ");
           System.out.print(s+" ");
          for(int i=1;i<=8;i++)
          {
          t=f+s;
           System.out.print(" "+t);
           f=s;
           s=t;
        }
           break;
            case 2:
             s=0;
           System.out.print("enter number to get sum of digit ");
           int n=Integer.parseInt(br.readLine());
           while(n>0)
           {
               s=s+n%10;
               n=n/10;
            }
            System.out.println(".Sum of digit of number "+s);
            break;
            default :
            System.out.print("invalid input ");
        }
 }//end method
}	//end class
                  