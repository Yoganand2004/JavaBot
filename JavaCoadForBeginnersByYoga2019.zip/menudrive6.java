/**  Using a switch case statement write a Menu Driven program
 * 
  NO 1:MENSENNB NUMBER from 1 to 200 
  NO 2:triangle pattern of @ and #
 * 
 */
import java.io.*;
/**
 * copy last page
 */
public class menudrive6
{
    
    public void display ()throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Menudriven");
        System.out.println("1.MENSENNB NUMBER from 1 to 200 ");
        System.out.println("2. triangle pattern of @ and #");
        System.out.println("ENTER CHOICE");
          int n=Integer.parseInt(br.readLine());
          
          
          switch(n)
          {
          case 1:
          for(int i=1;i<=20;i++)
          {
             double a=(Math.pow(2,i))-1.0;
           
              System.out.println(a+" ");
            }
            break;
            case 2:
           System.out.println("enter range of number");
           int n2=Integer.parseInt(br.readLine());
           
           for(int x=1;x<=n2;x++)
           {
                
               for(int j=1;j<=x;j++)
               {
                   if(x%2==1)
               System.out.print("# ");
               else
               {
                    System.out.print("@ ");
                }

            }
               System.out.println();
            }
            break;
            default :
            System.out.print("invalid input ");
        }
 }//end method
}	//end class
       