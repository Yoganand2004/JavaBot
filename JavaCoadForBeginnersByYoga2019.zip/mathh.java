public class mathh 
{
    public int display()
    {
        double x=5.0;
        int y=(int)(Math.random()+5);
        return y;
    }
}
    