/**
 * Write a program to input name and vehicle number
 * and print parking charge at the rate of given criteria
 */
import java.io.*;

/**
 * Write a description of class Parking_lot here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Parking_lot
{
  
    String name;
    int vno,hours;
    double bill;

    
    public void input()throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter your name");
        name=br.readLine();
        System.out.println("Enter your vehicle number");
        vno=Integer.parseInt(br.readLine());
        System.out.println("Enter total hours :");
        hours=Integer.parseInt(br.readLine());
    
        
    }//end method
    public void compute()
    {
        if(hours>1)
        bill=3+1.5*(hours-1);
        else
        bill=3;
      
    }//end method
    public void display()
    {
      
        
                System.out.println("Name  :"+name);
                 System.out.println("Total hours :      "+hours);
                   System.out.println("Total charge :      "+bill);
                }//end method
     

                  
            public  void main()throws IOException
    {
       Parking_lot ob=new Parking_lot();
        ob.input();
        ob.compute();
        ob.display();
   }//end method
}	//end class
   
                        
        

    