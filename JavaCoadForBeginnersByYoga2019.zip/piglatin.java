/**Write a program to print piglatin word
 * 
 */import java.io.*;
public class piglatin
{
    public void toPiglat()throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter a string");
        String str=br.readLine();
        String s=str;
        String st="";
        int l=str.length();
        str=str.toUpperCase();
        for(int x=0;x<l;x++)
        {
            char ch=str.charAt(x);
            if(ch!='A'&&ch!='E'&&ch!='I'&&ch!='O'&&ch!='U')
            {
                st=st+ch;
            }
            else
            {
                str=str.substring(x);
                break;
            }
        }
        str=str+st+"AY";
        System.out.println("piglatin string for "+s+" is "+str);
       }//end method
}	//end class
    