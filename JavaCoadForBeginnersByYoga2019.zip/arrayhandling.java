import java.io.*;
/**
 *Write a program to input 10 Cities and print its name along with STD Code
 
 */
public class arrayhandling
{
    public void mains() throws IOException
    {
        String [] city=new String[10];
        String [] stdcode=new String[10];
        int result=0;
        String c;
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter 10 city name");
        for(int i=0;i<10;i++)
        {
            city[i]=br.readLine();
        }
        System.out.println("Enter 10 std code");
        for(int i=0;i<10;i++)
        {
             stdcode[i]=br.readLine();
            }
             System.out.println("Enter city to be search");
        c=br.readLine();
        for(int i=0;i<10;i++)
        {
            if(city[i].equals(c))
            {
          System.out.println("Search successful"+city[i]+city[i]+"std :"+stdcode[i]);
          result=1;
          break;
        }
        }
            if(result==0)
            {
                  System.out.println("Search Usuccessful,no such city found in the list");
                }
          }//end method
}	//end class
   
                        
            
        