/**
 * print niven number
   */
import java.io.*;

public class Niven_Number
{
   
    public void ckeck()throws IOException
    {
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

{
    
    System.out.println("Enter the Number");
    int num=Integer.parseInt(br.readLine());
    int t=num,sum=0,f;
    
    while(t>0)
    {
        f=t%10;
        sum=sum+f;
        t=t/10;
        
    }
    if(num%sum==0)
    {
        System.out.println("Entered Number is Niven Number");
        }
        else
        {
         System.out.println("Entered Number is not Niven Number");
        }
    }

    }//end method
}	//end class
        
         
         
         
            
        