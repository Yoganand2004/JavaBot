/**
 * Write a program to input name and price of book
 * and print amount after discount.
 */import java.io.*;
public class bookfair
{
    String Bname;
    int price;
    

    
    public void input()throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter  name");
        Bname=br.readLine();
        System.out.println("Enter price of books");
        price=Integer.parseInt(br.readLine());
        
        
    }//end method
    public void compute()
    {
        int dis;
        if(price>0&&price<=1000)
            dis=(2*price)/100;
            else if(price>1000&&price<=3000)
            dis =(10*price)/100;
            else 
            dis =(15*price)/100;
      price=price-dis;
      
    }//end method
    public void display()
    {
      
        
                System.out.println("Name   "+Bname);
                 System.out.println("price of book after discount "+price);
                }//end method
     

                  
            public  void main()throws IOException
    {
        bookfair ob=new bookfair();
        
        ob.input();
        ob.compute();
        ob.display();
   }//end method
}	//end class
   
                        
        

    