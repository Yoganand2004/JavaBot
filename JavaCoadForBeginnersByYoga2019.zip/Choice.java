
/**
 * Write a program to Overload a function 
 * and compare to accept two integer and print greatest integer.
 * accept two Character and print highest numeric value.
 * accept two String and print longer String.
 */
public class Choice
{
    void compare(int a,int b)
    {
        //greatest integer
        if(a>b)
        {
            
          System.out.println("greatest integer="+a);
        }
        else //smallest integer
        
        {
             System.out.println("smallest integer="+b);
            }
            
        }//end method
        void compare(char a,char b)
    {
        if((int)a>(int)b)
        {
                 System.out.println("highest numeric value="+a);
                }
                else
                {
                         System.out.println("smallest numeric value="+b);
                        }
                    }//end method
          void compare(String a,String b)
                    {
           if(a.length()>b.length())
                        {
                              System.out.println("longest string="+a);
                            }
                            else
                            {
                                  System.out.println("smallest string"+b);
                                }
                           }//end method
}	//end class
   
                        
            
            
            
        
    