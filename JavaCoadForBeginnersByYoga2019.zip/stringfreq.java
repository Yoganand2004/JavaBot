/** 
 * Write a program to 
 * PRINT HIGHEST FREQUENCY WORD
 */
import java.io.*;
public class stringfreq
{
  
    public void sample()throws IOException
    {
        
        
         BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
              
         System.out.println("PRINTING HIGHEST FREQUENCY WORD");
       
         System.out.println("Enter a sentence");
        
        String str=br.readLine();
        
        int f=0;
        String st="",str1="";
        int l=str.length();
        int s=0;
        for(int x=0;x<l;x++)
        {
            char ch=str.charAt(x);
            if(ch!=' ')
            {
                int a=(int)ch;
                s=s+a;
                    st=st+ch;
                
            }
            else
            {
                if(s>f)
                {
                    str1=st;
                }
                s=0;
                st="";
            }
        }
        System.out.println(str1);
         }//end method
}	//end class
   
                        