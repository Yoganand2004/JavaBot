/**
 * Write a program to Overload a function 
 * and accept a String and chacter and frequency in a string.
 */ 
public class Overloaded
{
    int i;
    public void check(String str ,char ch)
    {
        int c=0;
        str=str.toLowerCase();
        for(i=0;i<str.length();i++)
        {
            if(ch==str.charAt(i))
            {
                c++;
            }
        }
        System.out.println("number of "+ch+"present is "+c);
    }
    public void check(String s1)
    {
        char ch;
        s1=s1.toLowerCase();
         for(i=0;i<s1.length();i++) 
         {
             ch=s1.charAt(i);
             if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
             {
                         System.out.print(ch+" ");
                        }
                    }
                }//end method
}	//end class
   
                        
